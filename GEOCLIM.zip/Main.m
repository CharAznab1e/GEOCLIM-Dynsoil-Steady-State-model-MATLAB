% =========================================================================
% PROGRAM DESCRIPTION
% =========================================================================
% This MATLAB code accompanies the manuscript:
% "Rainfall amplified sea-level control on silicate weathering in the 
%  Indo-Pacific Convergence Zone during Quaternary glacials"
% 
% Target Journal: Communications Earth & Environment
% Current Status: Under review (as of when this comment was written)
%
% IMPORTANT: Please do not cite or distribute this code until the 
%            associated manuscript is formally published. We will update
%            this repository's README upon publication, at which point we
%            warmly welcome its use and citation. If I remember, I'll also
%            update this very comment — but the README will be the 
%            definitive source for current information.
%
% ABOUT THIS IMPLEMENTATION:
% The core model parameters and physical formulations are derived from the
% original GEOCLIM-Dynsoil-Steady-State model (written in Fortran) by:
%   Goddéris, Y. & Donnadieu, Y. 
%   "A sink- or a source-driven carbon cycle at the geological timescale? 
%    Relative importance of palaeogeography versus solid Earth degassing 
%    rate in the Phanerozoic climatic evolution."
%   Geol. Mag. 156, 355–365 (2019). 
%   https://doi.org/10.1017/S0016756818000130
%
% CRITICAL NOTE ON TEST DATA:
% The environmental data file ERA5_1981-2018_30minx30min.nc used in our 
% testing is NOT suitable for actual scientific simulations. This data 
% was only used to verify that the code runs correctly, and the results 
% from this test dataset have NO scientific significance. All other 
% parameters are taken directly from the original model.
%
% The actual data used in our research is described in detail in the 
% manuscript and is fully reproducible following the methods section.
%
% ORIGINAL MODEL SOURCE:
% The original Fortran implementation of GEOCLIM can be found at:
%   https://github.com/piermafrost/GEOCLIM-dynsoil-steady-state
%
% Our contribution here is to provide a more user-friendly, automated, and
% extensible MATLAB implementation. We have also implemented point-to-point
% calculation functionality for physical erosion and chemical weathering
% fluxes, which you can find in the subsequent program comments.
% 
% If you use this model in your research, please be sure to cite both our 
% manuscript (once published) and the foundational work by Goddéris & 
% Donnadieu (2019).
%
% CONTACT:
% For scientific questions or collaboration inquiries, please contact the
% corresponding authors:
%   zhaokaixu@qdio.ac.cn  OR  zhaodebo@qdio.ac.cn
%
% For informal chats, bug reports, or code-related questions, feel free to
% reach out to the code author (that's me!):
%   yangyifei@qdio.ac.cn
%
% Happy modeling! May your weathering fluxes be ever in your favor.
% =========================================================================

%% Set the path

cd('Your path to Main.m') % Please change the path to your own path pointing to Main.m
savePath = ('Your path to save netCDF'); % Change this to your desired output directory

%% Load necessary variables

cd('input')
clim_fname = 'ERA5_1981-2018_30minx30min.nc';
params_file = readmatrix('params_Parketal2019_573_5litho.csv');
cell_area = ncread('grid_30minx30min_sphere.nc','area');
list_i = ncread('grid_30minx30min_sphere.nc','longitude');
list_j = ncread('grid_30minx30min_sphere.nc','latitude');
longitude = ncread('grid_30minx30min_sphere.nc','longitude');
latitude = ncread('grid_30minx30min_sphere.nc','latitude');
land_area = ncread('landfrac_ERA5_30minx30min.nc','lsm');
slope = ncread('slope_360_720_PD.nc','slope');
temperature = ncread(clim_fname, 't2m');
temperature = temperature';
runoff = ncread(clim_fname, 'ro');
lith_frac = ncread('lithology_fraction_PI_5class_30minx30min.nc', 'lithfrac');

%% Data preprocessing
nlith = size(lith_frac, 3);  % Number of lithology types
nrun = size(params_file,1);
nparams = size(params_file,2)/nlith;
valid_mask = ~isnan(temperature);
[rows, cols] = size(cell_area); % Determine grid dimensions from cell_area size
temperature = temperature + 273.15; % Convert from Celsius to Kelvin

cd('..')
cd('source')
if nrun == 1
    params = load_params_single_run(params_file, nlith, nparams);
else
    params = load_params_multiple_runs(params_file, nlith, nrun, nparams);
end
mparam = mean(params,2);

%% Run the model
% =========================================================================
% NOTE ON PARALLEL COMPUTING
% =========================================================================
% This implementation uses parallel computing to significantly reduce 
% runtime. By default, we use 24 parallel workers for optimal performance.
%
% However, if your computer has limited resources or you encounter 
% memory issues, you have several options:
%
% Option 1: Use automatic CPU core detection
% =======================================================
% We have prepared code in the comments of \source\dynsoil_geographic_loop.m
% that automatically detects your CPU cores and sets the optimal number 
% of parallel workers. Simply uncomment the provided section.
%
% Option 2: Disable parallel computing entirely
% ============================================
% 1. Open: \source\dynsoil_geographic_loop.m
% 2. Remove or comment out the following lines:
%    if isempty(gcp('nocreate'))
%        parpool('local', numWorkers);
%    end
% 3. Change all 'parfor' loops to regular 'for' loops
%
% This will revert to serial computation, which is slower but more 
% memory-friendly. The choice depends on your hardware and patience level!
%
% HARDWARE TIPS:
% - For best performance, ensure your CPU has at least 24 physical cores
% - Monitor memory usage during execution
% - Adjust the number of workers based on your specific system resources
% =========================================================================

[E, W, h, xs, Fsilwth] = dynsoil_geographic_loop(temperature, runoff, slope, lith_frac, params, rows, cols, nlith, nrun, cell_area);

% =========================================================================
% MODEL USAGE OPTIONS
% =========================================================================
% Our test program Main.m aims to faithfully reproduce the original
% GEOCLIM-Dynsoil-Steady-State model. Therefore, we utilize the 
% dynsoil_geographic_loop function (\source\dynsoil_geographic_loop.m)
% for global-scale weathering calculations.
%
% IMPORTANT: This approach requires complete, spatially consistent climate
% and topography data with uniform resolution across all input fields.
%
% =========================================================================
% ALTERNATIVE: SINGLE-POINT CALCULATION
% =========================================================================
% If you prefer a more convenient way to calculate weathering fluxes at 
% individual locations (single-point input → single-point output), we
% recommend using the dynsoil_steady_state function 
% (\source\dynsoil_steady_state.m).
%
% EXAMPLE USAGE:
% =============
% temp_val = ...;     % Temperature at the point (K)
% runoff_val = ...;   % Runoff at the point (m/year)
% slope_val = ...;    % Slope at the point (m/m, dimensionless)
%
% for r = 1:nrun
%     for k = 1:nlith
%         [h_val, E_val, xs_val, W_val] = dynsoil_steady_state(...
%             temp_val, runoff_val, slope_val, params(:,k,r));
%         Erosion = E_val;
%         Weathering = W_val .* params(13, k, r);
%     end
% end
%
% ADVANTAGES OF SINGLE-POINT CALCULATION:
% - No need for complete global datasets
% - Lower memory requirements
% - Faster debugging and parameter testing
% - Ideal for local or regional studies
%
% Choose the method that best suits your research needs!
% =========================================================================

%% Visualization
% =========================================================================
% VISUALIZATION NOTES
% =========================================================================
% During the visualization process, we provide the plotErosionWeathering 
% function to help you create plots of erosion and weathering patterns.
%
% DEFAULT COLORMAP:
% By default, we use the 'jet' colormap for visualizations. If you prefer
% a different colormap (e.g., 'parula', 'viridis', 'cividis', etc.), you 
% can modify the colormap settings at the end of:
%   /source/plotErosionWeathering.m
%
% IMPORTANT NOTE:
% This visualization function is designed for global-scale results generated
% by the dynsoil_geographic_loop function. If you plan to use the 
% point-to-point calculation method (via dynsoil_steady_state), this 
% plotting function will not be applicable, as it expects gridded data.
%
% CUSTOMIZATION TIPS:
% - You can adjust color limits using caxis()
% - For publication-quality figures, consider using perceptually uniform
%   colormaps like 'viridis' or 'plasma'
% - Modify the figure size and resolution according to your needs
% =========================================================================

[totalWeathering, avgErosion] = plotErosionWeathering(E, W, longitude, latitude, land_area, cell_area);
set(gca, 'YDir', 'normal', 'FontName', 'Arial');


%% Save results

%% Save and export results

% Calculate aggregated metrics:
% - Gridded weathering flux (summed over lithologies, averaged over runs)
Weathering = sum(mean(W, 4), 3);

% - Gridded erosion rate (summed over lithologies, averaged over runs)
Erosion = sum(mean(E, 4), 3);

% - Global degassing flux (summed spatially, over lithologies, averaged over runs)
degassing = sum(sum(sum(mean(Fsilwth, 4), 3)));

% =========================================================================
% DATA EXPORT OPTIONS
% =========================================================================
% We provide two main ways to export your results:
%
% 1. MATLAB VARIABLES (Recommended for further processing in MATLAB)
%    --------------------------------------------------------------
%    Use the variables calculated above (Weathering, Erosion, degassing)
%    if you plan to continue analysis within the MATLAB environment.
%
% 2. NETCDF FILES (Recommended for sharing, archiving, or use in other tools)
%    -----------------------------------------------------------------------
%    The saveToNetCDF function exports all raw data (including full 
%    lithology and run dimensions) to a standard NetCDF file.
%
%    Customization: You can modify the saveToNetCDF function in
%    /source/saveToNetCDF.m to include additional variables or change
%    the output format according to your needs.
%
%    Usage: saveToNetCDF(E, W, longitude, latitude, age, savePath, ...
%                        nlith, nrun, cell_area);
% =========================================================================

% Export to NetCDF file
saveToNetCDF(E, W, longitude, latitude, age, savePath, nlith, nrun, cell_area);

% =========================================================================
% END OF PROGRAM
% =========================================================================
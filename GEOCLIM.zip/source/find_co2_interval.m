function [kinf, ksup, xi] = find_co2_interval(CO2, CO2_levels)
    nlev = length(CO2_levels);

    if nlev == 1
        kinf = 1;
        ksup = 1;
        xi = 0;
    else
        kinf = 1;
        ksup = nlev;

        % Dichotomy search
        while (ksup - kinf > 1)
            k = kinf + floor((ksup - kinf) / 2);
            if CO2 >= CO2_levels(k)
                kinf = k;
            else
                ksup = k;
            end
        end

        % Calculate interpolation coefficient
        xi = interp_coeff(CO2, CO2_levels(kinf), CO2_levels(ksup), 'log');
    end
end

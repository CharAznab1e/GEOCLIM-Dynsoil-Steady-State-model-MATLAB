function varout = litho_average(list_i, list_j, lith_frac, varin)
    ncont = numel(list_i);
    varout = zeros(size(lith_frac, 2), 1);
    
    for k = 1:ncont
        i = list_i(k);
        j = list_j(k);
        
        
        varout(i,j) = sum(lith_frac(:,i,j) .* varin(:,i,j));
    end
end

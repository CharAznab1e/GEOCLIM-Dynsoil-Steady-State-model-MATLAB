function [globalTotalWeathering, globalAvgErosion] = plotErosionWeathering(E, W, longitude, latitude, land_area, cell_area)
    % Function: Process and visualize erosion rates and chemical weathering fluxes
    
    disp('## Visualization ##');
    
    % Data processing
    E(isnan(E)) = 0;
    Erosion = mean(sum(E, 3), 4) * 10^(3); % Convert to mm/year
    
    W(isnan(W)) = 0;
    Weathering = mean(sum(W, 3), 4);
    
    % Calculate global weathering flux
    globalWeathering = Weathering .* cell_area;
    globalTotalWeathering = sum(sum(globalWeathering)); % Calculate total global chemical weathering flux
    disp(['Total global chemical weathering flux: ', num2str(globalTotalWeathering, '%.2e'), ' mol/year']);
    
    globalAvgErosion = mean(Erosion(:)); % Calculate global average erosion rate
    disp(['Global average erosion rate: ', num2str(globalAvgErosion, '%.2e'), ' mm/year']);

    % Enhanced plotting with interpolation
    lon_interp = min(longitude):0.1:max(longitude);
    lat_interp = min(latitude):0.1:max(latitude);
    [lon_interp_grid, lat_interp_grid] = meshgrid(lon_interp, lat_interp);

    % Interpolate data for smoother visualization
    Weathering_interp = interp2(longitude, latitude, Weathering', lon_interp_grid, lat_interp_grid);
    Erosion_interp = interp2(longitude, latitude, Erosion', lon_interp_grid, lat_interp_grid);
    land_area_interp = interp2(longitude, latitude, land_area', lon_interp_grid, lat_interp_grid);

    % Identify land and ocean grid cells
    land_indices = land_area_interp > 0;
    non_land_indices = land_area_interp <= 0;

    % Handle missing values appropriately
    Erosion_interp(land_indices & isnan(Erosion_interp)) = 0;
    Weathering_interp(land_indices & isnan(Weathering_interp)) = 0;
    Erosion_interp(non_land_indices & Erosion_interp == 0) = NaN;
    Weathering_interp(non_land_indices & Weathering_interp == 0) = NaN;

    % Create figure for plotting
    figure('Color', 'w', 'Position', [100, 100, 1200, 400]);
    subplot_margin = 0.05;

    % First subplot: Erosion
    h1 = subplot(1, 2, 1);
    set(h1, 'Position', [0.05, 0.1, 0.45, 0.8]);
    h = imagesc(lon_interp, lat_interp, Erosion_interp);
    axis xy;
    set(gca, 'YDir', 'reverse', 'FontName', 'Times New Roman', 'Color', 'w');
    set(h, 'AlphaData', ~isnan(Erosion_interp));
    colorbar;
    applyColormap(gca); % Apply custom colormap
    xlabel('Longitude (\circ E)', 'FontName', 'Times New Roman');
    ylabel('Latitude (\circ N)', 'FontName', 'Times New Roman');
    title('Erosion (mm/year)', 'FontName', 'Times New Roman');
    grid off;
    xlim([min(lon_interp), max(lon_interp)]);
    ylim([min(lat_interp), max(lat_interp)]);
    set(gca, 'YDir', 'normal', 'FontName', 'Times New Roman');

    % Second subplot: Weathering
    h2 = subplot(1, 2, 2);
    set(h2, 'Position', [0.55, 0.1, 0.45, 0.8]);
    h = imagesc(lon_interp, lat_interp, Weathering_interp);
    axis xy;
    set(gca, 'YDir', 'normal', 'FontName', 'Times New Roman', 'Color', 'w');
    set(h, 'AlphaData', ~isnan(Weathering_interp));
    colorbar;
    applyColormap(gca); % Apply custom colormap
    xlabel('Longitude (\circ E)', 'FontName', 'Times New Roman');
    ylabel('Latitude (\circ N)', 'FontName', 'Times New Roman');
    title('Weathering (mol/m^2/year)', 'FontName', 'Times New Roman');
    grid off;
    xlim([min(lon_interp), max(lon_interp)]);
    ylim([min(lat_interp), max(lat_interp)]);
    set(gca, 'YDir', 'normal', 'FontName', 'Times New Roman');

end

% Helper function: Apply colormap
function applyColormap(ax)
    try
        colormap(ax, 'jett'); % Try using custom colormap
    catch ME
        warning('Custom colormap not available, using default.');
        colormap(ax, jet); % Fallback to default colormap if custom is not available
    end
end
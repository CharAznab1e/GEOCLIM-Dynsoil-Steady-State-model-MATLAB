function RPopt = reg_prod_opt(temp, runoff, param)
    % Calculate optimal soil production rate
    % Inputs:
    %   temp: temperature (K)
    %   runoff: runoff (m/yr)
    %   param: array of parameters [krp, Ea_rp, T0_rp]
    
    Rgas = 8.314; % Universal gas constant
    krp = param(4);
    Ea_rp = param(5);
    T0_rp = param(6);
    
    RPopt = krp * runoff * exp(-(Ea_rp / Rgas) * (1 / (temp) - 1 / T0_rp));
end

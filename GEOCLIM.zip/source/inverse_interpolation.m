function [CO2, curr_temp, curr_runf, curr_GMST, nstep] = inverse_interpolation(imposed_Fsilw, list_i, list_j, param, area, temp, runoff, slope, lith_frac, CO2_levels, GMST, PREC)
    % Initializing
    [k0, k1, Fsilw0, Fsilw1] = find_weathering_interval(imposed_Fsilw, list_i, list_j, param, area, temp, runoff, slope, lith_frac);
    CO2_0 = CO2_levels(k0);
    CO2_1 = CO2_levels(k1);

    Fsilw = Fsilw0;
    CO2 = CO2_0;
    nstep = 0;

    while abs((Fsilw - imposed_Fsilw) / imposed_Fsilw) > PREC
        if Fsilw > imposed_Fsilw
            Fsilw1 = Fsilw;
            CO2_1 = CO2;
        else
            Fsilw0 = Fsilw;
            CO2_0 = CO2;
        end

        % Interpolation mode
        dFsilw_dCO2 = (Fsilw1 - Fsilw0) / log(CO2_1 / CO2_0);
        CO2 = CO2_0 * exp((imposed_Fsilw - Fsilw0) / dFsilw_dCO2);

        % Climate interpolation
        xi = interp_coeff(CO2, CO2_levels(k0), CO2_levels(k1), 'log');
        [curr_temp, curr_runf, curr_GMST] = interpolate_climate(list_i, list_j, temp, runoff, GMST, k0, k1, xi);

        % Update Fsilw
        Fsilw = dynsoil_geographic_loop(list_i, list_j, area, curr_temp, curr_runf, slope, lith_frac, param);
        nstep = nstep + 1;
    end
end

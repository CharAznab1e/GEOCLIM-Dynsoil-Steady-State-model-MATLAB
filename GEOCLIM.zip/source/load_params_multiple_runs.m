function params = load_params_multiple_runs(params_file, nlith, nrun, nparams)
    % load_params_multiple_runs - Loads parameters from a CSV file for multiple runs.
    
    % Read the CSV file
    data = params_file;
    
    % Ensure the number of rows matches the number of runs and each row has enough values
    expected_cols_per_run = nparams * nlith;
    if size(data, 1) ~= nrun || size(data, 2) < expected_cols_per_run
        error('Number of rows or columns in the CSV does not match expected dimensions.');
    end
    
    % Initialize params with zeros
    params = zeros(nparams, nlith, nrun);
    
    % Fill the params array
    for r = 1:nrun
        for p = 1:nparams
            start_col = (p-1)*nlith + 1;
            end_col = p*nlith;
            params(p, :, r) = data(r, start_col:end_col);
        end
    end
end
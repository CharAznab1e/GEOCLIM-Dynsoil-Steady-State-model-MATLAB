function thickness = eq_reg_thick(RPopt, E, param)
    % Calculate equilibrium regolith thickness
    % Inputs:
    %   RPopt: optimal soil production rate
    %   E: erosion rate
    %   param: array of parameters [h0]
    
    h0 = param(7);
    thickness = max(h0 * log(RPopt / E), 0);
end

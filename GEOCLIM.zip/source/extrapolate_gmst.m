function GMST = extrapolate_gmst(co2_levels, GMST, mode)
    % Extrapolate GMST based on CO2 axis
    % Inputs:
    % - co2_levels: CO2 levels array (nCO2 x 1 or 1 x nCO2)
    % - GMST: GMST data array (nCO2 x 1 or 1 x nCO2)
    % - mode: Extrapolation mode ('linear' or 'log')
    % Output:
    % - GMST: Extrapolated GMST data

    % Ensure co2_levels and GMST are column vectors
    co2_levels = co2_levels(:); % Convert to column vector
    GMST = GMST(:);             % Convert to column vector

    % Determine extrapolation range
    switch mode
        case 'linear'
            co2_min = 0;
            co2_max = 4 * co2_levels(end);
        case 'log'
            co2_min = co2_levels(2) / 16;
            co2_max = co2_levels(end) * 32;
        otherwise
            error('Unsupported mode: %s', mode);
    end

    % Interpolation coefficients
    interp_coeff_lower = (co2_levels(1) - co2_levels(2)) / (co2_levels(3) - co2_levels(2));
    interp_coeff_upper = (co2_levels(end) - co2_levels(end-1)) / (co2_levels(end-2) - co2_levels(end-1));

    % Extrapolate GMST
    GMST = [...
        (1 - interp_coeff_lower) * GMST(1) + interp_coeff_lower * GMST(2); % Lower bound extrapolation
        GMST; % Original GMST data
        (1 - interp_coeff_upper) * GMST(end) + interp_coeff_upper * GMST(end-1) % Upper bound extrapolation
    ];
end
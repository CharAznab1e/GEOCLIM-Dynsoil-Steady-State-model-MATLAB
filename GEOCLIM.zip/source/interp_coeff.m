function coeff = interp_coeff(x, x0, x1, interpolation_mode)
    % Calculate interpolation coefficient based on mode
    switch interpolation_mode
        case 'linear'
            coeff = (x - x0) / (x1 - x0);
        case 'log'
            coeff = log(x / x0) / log(x1 / x0);
        otherwise
            error('Illegal interpolation mode: %s. Use "linear" or "log".', interpolation_mode);
    end
end

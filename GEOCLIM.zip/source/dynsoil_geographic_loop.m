function [E, W, h, xs, Fsilwth] = dynsoil_geographic_loop(temp, runoff, slope, lith_frac, params, rows, cols, nlith, nrun, cell_area)
    % Function: Parallel computation of erosion rates and chemical weathering fluxes
    %
    % Inputs:
    %   temp        - Temperature data matrix (rows x cols)
    %   runoff      - Runoff data matrix (rows x cols)
    %   slope       - Slope data matrix (rows x cols)
    %   cell_area   - Grid cell area matrix (rows x cols)
    %   lith_frac   - Lithology fraction matrix (rows x cols x nlith)
    %   params      - Parameter matrix (num_params x nlith x nrun)
    %   rows        - Number of rows
    %   cols        - Number of columns
    %   nlith       - Number of lithology types
    %   nrun        - Number of runs
    %
    % Outputs:
    %   Fsilwth     - Chemical weathering flux matrix (rows x cols x nlith x nrun)
    %   E           - Erosion rate matrix (rows x cols x nlith x nrun)
    %   W           - Intermediate variable matrix (rows x cols x nlith x nrun) => Fsilwth

    disp('## Running the model ##')
    tic;

    numWorkers = 24;  % Specify number of parallel workers

    % Start parallel pool
    if isempty(gcp('nocreate'))
        parpool('local', numWorkers);  % Set parallel pool size to numWorkers
    end

    % % Automatically start a local parallel pool using the default number of workers.
    % % If no parallel pool is currently running, parpool('local') will launch one
    % % with a size automatically determined by MATLAB (typically equal to the number
    % % of logical CPU cores available on the system).
    % 
    % if isempty(gcp('nocreate'))
    %     parpool('local');
    % end

    % Precompute valid cells (non-NaN)
    valid_indices = ~isnan(temp) & ~isnan(runoff) & ~isnan(slope);

    % Initialize global variables
    E_local = zeros(rows, cols, nlith, nrun);
    W_local = zeros(rows, cols, nlith, nrun);
    h_local = zeros(rows, cols, nlith, nrun);
    xs_local = zeros(rows, cols, nlith, nrun);
    Fsilwth_local = zeros(rows, cols, nlith, nrun);  % Added initialization
    
    % Parallel loop
    parfor i = 1:rows
        
        temp_E = zeros(cols, nlith, nrun); % Local variable
        temp_W = zeros(cols, nlith, nrun); % Local variable
        temp_h = zeros(cols, nlith, nrun); % Local variable
        temp_xs = zeros(cols, nlith, nrun); % Local variable
        temp_Fsilwth = zeros(cols, nlith, nrun); % Local variable

        for j = 1:cols
            if valid_indices(i, j)
                temp_val = temp(i, j);
                runoff_val = runoff(i, j);
                slope_val = slope(i, j);

                for r = 1:nrun
                    for k = 1:nlith
                        [h_val, E_val, xs_val, W_val] = dynsoil_steady_state(temp_val, runoff_val, slope_val, params(:,k,r));
                        temp_E(j, k, r) = E_val;
                        temp_W(j, k, r) = W_val .* params(13, k, r);
                        temp_Fsilwth(j, k, r) = W_val .* params(13, k, r) * lith_frac(i, j, k) * cell_area(i, j);
                        temp_h(j, k, r) = h_val;        % Fixed: added indices
                        temp_xs(j, k, r) = xs_val;      % Fixed: added indices
                    end
                end
            end
        end

        % Merge local variables into global variables
        E_local(i, :, :, :) = temp_E;
        W_local(i, :, :, :) = temp_W;
        h_local(i, :, :, :) = temp_h;
        xs_local(i, :, :, :) = temp_xs;
        Fsilwth_local(i, :, :, :) = temp_Fsilwth;
    end

    % Assign results to output parameters
    E = E_local;
    W = W_local;
    h = h_local;
    xs = xs_local;
    Fsilwth = Fsilwth_local;
    
    disp('## Run Complete ##')
    elapsedTime = toc;
    minutes = floor(elapsedTime / 60); % Calculate full minutes
    seconds = mod(elapsedTime, 60);    % Calculate remaining seconds
    % Print runtime in "X minutes Y.ZZZ seconds" format including milliseconds
    fprintf('Run Time: %d minutes %.1f seconds.\n', minutes, seconds);
end
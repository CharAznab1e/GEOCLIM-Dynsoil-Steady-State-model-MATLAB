function [temp, runoff, gmst] = interpolate_climate(list_i, list_j, temp_lvl, runoff_lvl, gmst_lvl, k0, k1, xi)
    % Interpolate climate variables (temperature, runoff, and GMST) between two levels
    %
    % Inputs:
    %   list_i    - Row indices of continental grid cells (1D vector)
    %   list_j    - Column indices of continental grid cells (1D vector)
    %   temp_lvl  - 3D temperature data (rows × cols × nlevels)
    %   runoff_lvl - 3D runoff data (rows × cols × nlevels)
    %   gmst_lvl  - 1D GMST data for each level (nlevels × 1)
    %   k0        - Index of first climate level
    %   k1        - Index of second climate level
    %   xi        - Interpolation weight (0 = full k0, 1 = full k1)
    %
    % Outputs:
    %   temp      - Interpolated 2D temperature field (rows × cols)
    %   runoff    - Interpolated 2D runoff field (rows × cols)
    %   gmst      - Interpolated global mean surface temperature (scalar)

    ncont = length(list_i);
    temp = zeros(size(temp_lvl, 1), size(temp_lvl, 2));
    runoff = zeros(size(runoff_lvl, 1), size(runoff_lvl, 2));

    % Interpolate temperature and runoff for continental grid cells only
    for k = 1:ncont
        i = list_i(k);
        j = list_j(k);
        % Linear interpolation between level k0 and k1
        temp(i, j) = (1 - xi) * temp_lvl(i, j, k0) + xi * temp_lvl(i, j, k1);
        runoff(i, j) = (1 - xi) * runoff_lvl(i, j, k0) + xi * runoff_lvl(i, j, k1);
    end

    % Interpolate global mean surface temperature
    gmst = (1 - xi) * gmst_lvl(k0) + xi * gmst_lvl(k1);
end
function params = load_params_single_run(params_file, nlith, nparams)
    % load_params_single_run - Loads parameters from a CSV file for single run.
    
    % Read the CSV file
    data = params_file;
    
    % Ensure the number of columns matches the expected number (nparams * nlith)
    expected_cols = nparams * nlith;
    if size(data, 2) ~= expected_cols
        error('Number of columns in the CSV does not match expected dimensions.');
    end
    
    % For a single run, we assume the first row contains the parameters
    single_run_data = data(1, :); % Assuming the first row is for single run
    
    % Initialize params with zeros
    params = zeros(nparams, nlith);
    
    % Fill the params array
    for p = 1:nparams
        start_col = (p-1)*nlith + 1;
        end_col = p*nlith;
        params(p, :) = single_run_data(start_col:end_col);
    end
end
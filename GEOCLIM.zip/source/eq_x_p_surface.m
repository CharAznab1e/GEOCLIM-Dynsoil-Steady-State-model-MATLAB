function proportion = eq_x_p_surface(h, E, K, param)
    % Calculate proportion of primary phases at the surface
    % Inputs:
    %   h: soil thickness
    %   E: erosion rate
    %   K: constant
    %   param: array of parameters [sigma]
    
    sigma = param(12);
    proportion = exp(-K * ((h / E)^(sigma + 1)) / (sigma + 1));
end

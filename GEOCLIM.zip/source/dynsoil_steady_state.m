function [h, E, xs, W] = dynsoil_steady_state(temp, runoff, slope, param)
% Calculate variables for steady-state weathering

% Inputs:
% temp    - Temperature
% runoff  - Runoff
% slope   - Slope
% param   - Lithology parameter matrix
% nlith   - Number of lithologies

% Outputs:
% h  - Regolith thickness
% E  - Erosion rate
% xs - Surface primary phase proportion
% W  - Weathering rate

% Calculate erosion rate 
E = erosion(temp, runoff, slope, param);

if E > 0
    % Calculate optimal regolith production rate 
    RPopt = reg_prod_opt(temp, runoff, param);
    % Calculate regolith thickness 
    h = eq_reg_thick(RPopt, E, param);
    % Calculate dissolution constant 
    Kmain = dissolution_constant(temp, runoff, param);
    % Calculate surface primary phase proportion 
    xs = eq_x_p_surface(h, E, Kmain, param);
    % Calculate weathering rate
    W = steady_state_weathering(E, xs);
else
    % Set relevant values to zero when erosion rate is 0
    h = 0;
    E = 0;
    xs = 1;
    W = 0;
end
end
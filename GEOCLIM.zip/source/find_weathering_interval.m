function [kinf, ksup, Fsilw_inf, Fsilw_sup] = find_weathering_interval(imposed_Fsilw, list_i, list_j, param, area, temp, runoff, slope, lith_frac)
    nlev = size(temp, 3);
    kinf = 1;
    ksup = nlev;

    % Initial calculation
    Fsilw_inf = dynsoil_geographic_loop(list_i, list_j, area, temp(:, :, kinf), runoff(:, :, kinf), slope, lith_frac, param);
    Fsilw_sup = dynsoil_geographic_loop(list_i, list_j, area, temp(:, :, ksup), runoff(:, :, ksup), slope, lith_frac, param);

    % Dichotomy search
    while (ksup - kinf > 1)
        k = kinf + floor((ksup - kinf) / 2);
        Fsilw_curr = dynsoil_geographic_loop(list_i, list_j, area, temp(:, :, k), runoff(:, :, k), slope, lith_frac, param);
        if imposed_Fsilw >= Fsilw_curr
            kinf = k;
            Fsilw_inf = Fsilw_curr;
        else
            ksup = k;
            Fsilw_sup = Fsilw_curr;
        end
    end
end

function saveToNetCDF(E, W, longitude, latitude, age_p, savePath, nlith, nrun, cell_area)
% SAVE TONETCDF - Save erosion and weathering data to NetCDF file
%
% Inputs:
%   E          - Erosion rate data (lon x lat x nlith x nrun)
%   W          - Weathering flux data (lon x lat x nlith x nrun)
%   longitude  - Longitude vector
%   latitude   - Latitude vector
%   age_p      - Age in years BP
%   savePath   - Directory path to save the file
%   nlith      - Number of lithology types
%   nrun       - Number of model runs
%   cell_area  - Grid cell area (lon x lat)

disp('## Processing outputs ##');

disp('## Outputting ##');
% Construct full filename with age information
filename = sprintf('Output_%skyrBP.nc', num2str(age_p / 1000));
full_path = fullfile(savePath, filename);

try
    % Create new NetCDF file with NETCDF4 format
    ncid = netcdf.create(full_path, 'NETCDF4');

    % Create dimension indices
    nnlith = 0 : nlith-1;
    nnrun = 1 : nrun;

    % Define dimensions
    lon_dim_id = netcdf.defDim(ncid, 'longitude', length(longitude));
    lat_dim_id = netcdf.defDim(ncid, 'latitude', length(latitude));
    nlith_dim_id = netcdf.defDim(ncid, 'nlith', length(nnlith));
    nrun_dim_id = netcdf.defDim(ncid, 'nrun', length(nnrun));

    % Define variables with dimensions
    lon_id = netcdf.defVar(ncid, 'longitude', 'double', lon_dim_id);
    lat_id = netcdf.defVar(ncid, 'latitude', 'double', lat_dim_id);
    E_id = netcdf.defVar(ncid, 'Erosion', 'double', [lon_dim_id, lat_dim_id, nlith_dim_id, nrun_dim_id]);
    W_id = netcdf.defVar(ncid, 'Weathering', 'double', [lon_dim_id, lat_dim_id, nlith_dim_id, nrun_dim_id]);
    nlith_id = netcdf.defVar(ncid, 'nlith', 'double', nlith_dim_id);
    nrun_id = netcdf.defVar(ncid, 'nrun', 'double', nrun_dim_id);
    area_id = netcdf.defVar(ncid, 'Cell Area', 'double', [lon_dim_id, lat_dim_id]);

    % Add variable units
    netcdf.putAtt(ncid, E_id, 'units', 'mm/year');
    netcdf.putAtt(ncid, W_id, 'units', 'mol/m^2/year');
    netcdf.putAtt(ncid, lon_id, 'units', 'degrees_east');
    netcdf.putAtt(ncid, lat_id, 'units', 'degrees_north');
    netcdf.putAtt(ncid, area_id, 'units', 'm^2');
    netcdf.putAtt(ncid, nlith_id, 'units', '-');
    netcdf.putAtt(ncid, nrun_id, 'units', '-');

    % Define missing value fill attributes
    netcdf.putAtt(ncid, E_id, '_FillValue', -9999);
    netcdf.putAtt(ncid, W_id, '_FillValue', -9999);
    netcdf.putAtt(ncid, nlith_id, '_FillValue', -9999);
    netcdf.putAtt(ncid, nrun_id, '_FillValue', -9999);
    netcdf.putAtt(ncid, area_id, '_FillValue', -9999);

    % Add global attributes with age information
    netcdf.putAtt(ncid, netcdf.getConstant('NC_GLOBAL'), 'age_years_BP', age_p);
    netcdf.putAtt(ncid, netcdf.getConstant('NC_GLOBAL'), 'age_kyr_BP', age_p/1000);
    netcdf.putAtt(ncid, netcdf.getConstant('NC_GLOBAL'), 'creation_date', datestr(now));
    
    % End definition mode
    netcdf.endDef(ncid);

    % Write coordinate and dimension data
    netcdf.putVar(ncid, lon_id, longitude);
    netcdf.putVar(ncid, lat_id, latitude);
    netcdf.putVar(ncid, nlith_id, nnlith);
    netcdf.putVar(ncid, nrun_id, nnrun);

    % Write data variables
    netcdf.putVar(ncid, area_id, cell_area);
    netcdf.putVar(ncid, E_id, E);
    netcdf.putVar(ncid, W_id, W);

    % Close NetCDF file
    netcdf.close(ncid);

    disp(['Data successfully saved to ', full_path]);

catch ME
    % Handle errors gracefully
    if exist('ncid', 'var') && ishandle(ncid)
        try
            netcdf.close(ncid);
        catch
            warning('Failed to close the NetCDF file.');
        end
    end
    error(['Error saving data to NetCDF: ', ME.message]);
end
end
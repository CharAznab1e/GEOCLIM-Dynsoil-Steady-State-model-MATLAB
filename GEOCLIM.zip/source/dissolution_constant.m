function dissolution_rate = dissolution_constant(temp, runoff, param)
    % Calculate dissolution constant
    % Inputs:
    %   temp: temperature (K)
    %   runoff: runoff (m/yr)
    %   param: array of parameters [kd, kw, Ea, T0]
    
    Rgas = 8.314; % Universal gas constant
    kd = param(8);
    kw = param(9);
    Ea = param(10);
    T0 = param(11);
    
    dissolution_rate = kd * (1 - exp(-kw * runoff)) * ...
        exp((Ea / Rgas) * (1 / T0 - 1 / (temp)));
end

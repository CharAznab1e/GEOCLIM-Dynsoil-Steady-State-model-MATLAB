function erosion_rate = erosion(temp, runoff, slope, param)
    % Calculate physical erosion rate
    % Inputs:
    %   temp: temperature (K)
    %   runoff: runoff (m/yr)
    %   slope: slope
    %   param: array of parameters [ke, a, b]
    ke = param(1);
    a = param(2);
    b = param(3);
    % erosion_rate = ke * (runoff^a) * (slope^b) * max(2.0, temp-273.15); % BQART-like
    erosion_rate = ke * (runoff^a) * (slope^b);
    % SEMMA Butcher et al. (2006) 

end

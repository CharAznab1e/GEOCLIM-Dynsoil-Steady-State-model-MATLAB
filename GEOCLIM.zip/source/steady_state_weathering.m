function W = steady_state_weathering(E, x_p_surf)
    % Calculate steady-state weathering rate
    % Inputs:
    %   E         - Erosion rate [dimension depends on model]
    %   x_p_surf  - Surface primary mineral fraction [dimensionless, 0-1]
    % Output:
    %   W         - Weathering rate [same dimension as E]
    
    W = E * (1 - x_p_surf);
end